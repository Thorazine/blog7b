@extends('layouts.default')


@section('title', 'Home page')



@section('content')
    Index
@stop
