@extends('layouts.default')


@section('title', $page->title)



@section('content')
	{!! $page->body !!}
@stop
