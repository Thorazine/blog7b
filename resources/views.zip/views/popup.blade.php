

<div class="popup">
	<div class="popup-header">
		Header
		<button class="close">close</button>
	</div>
	<div class="popup-body">
		Body
	</div>
	<div class="popup-footer">
		Footer
		<button class="close">close</button>
	</div>

</div>
